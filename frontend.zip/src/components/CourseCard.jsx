function CourseCard({ title, instructor, price, image }) {

  const handleEnroll = () => {
    const existing = JSON.parse(localStorage.getItem("courses")) || [];

    const newCourse = { title, instructor, price };

    localStorage.setItem("courses", JSON.stringify([...existing, newCourse]));

    alert("Enrolled successfully!");
  };

  return (
    <div style={{
      border: "1px solid #ddd",
      borderRadius: "12px",
      width: "260px",
      overflow: "hidden",
      boxShadow: "0 4px 10px rgba(0,0,0,0.1)"
    }}>
      
      {/* Image */}
      <img
        src={image}
        alt={title}
        style={{ width: "100%", height: "150px", objectFit: "cover" }}
      />

      {/* Content */}
      <div style={{ padding: "12px" }}>
        <h3>{title}</h3>
        <p>{instructor}</p>
        <p><b>₹{price}</b></p>

        <button
          onClick={handleEnroll}
          style={{
            background: "blue",
            color: "white",
            padding: "8px",
            border: "none",
            borderRadius: "6px",
            cursor: "pointer",
            width: "100%"
          }}
        >
          Enroll
        </button>
      </div>
    </div>
  );
}

export default CourseCard;