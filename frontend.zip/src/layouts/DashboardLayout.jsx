import { Link } from "react-router-dom";

function DashboardLayout({ user, children }) {
  return (
    <div style={{ display: "flex", height: "100vh", fontFamily: "Arial" }}>

      {/* SIDEBAR */}
      <div style={{
        width: "240px",
        background: "#0f172a",
        color: "white",
        padding: "20px"
      }}>
        <h2 style={{ marginBottom: "30px" }}>Coaching Pro</h2>

        <nav style={{ display: "flex", flexDirection: "column", gap: "12px" }}>
          <Link style={{ color: "white", textDecoration: "none" }} to="/dashboard">
            📊 Dashboard
          </Link>

          <Link style={{ color: "white", textDecoration: "none" }} to="/courses">
            📚 Courses
          </Link>

          <Link style={{ color: "white", textDecoration: "none" }} to="/profile">
            👤 Profile
          </Link>
        </nav>
      </div>

      {/* MAIN AREA */}
      <div style={{ flex: 1, background: "#f4f6f9" }}>

        {/* TOP BAR */}
        <div style={{
          background: "white",
          padding: "15px 20px",
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          boxShadow: "0 2px 8px rgba(0,0,0,0.05)"
        }}>
          <h3>Dashboard</h3>

          <div>
            👋 {user?.username} ({user?.role})
          </div>
        </div>

        {/* PAGE CONTENT */}
        <div style={{ padding: "20px" }}>
          {children}
        </div>

      </div>
    </div>
  );
}

export default DashboardLayout;