import CourseCard from "../components/CourseCard";

function Courses() {
  const courses = [
    {
      id: 1,
      title: "Web Development",
      instructor: "John",
      price: 1999,
      image: "https://images.unsplash.com/photo-1498050108023-c5249f4df085"
    },
    {
      id: 2,
      title: "React Mastery",
      instructor: "Sarah",
      price: 2999,
      image: "https://images.unsplash.com/photo-1633356122544-f134324a6cee"
    },
    {
      id: 3,
      title: "UI/UX Design",
      instructor: "David",
      price: 1499,
      image: "https://images.unsplash.com/photo-1581291518857-4e27b48ff24e"
    }
  ];

  return (
    <div style={{ padding: "20px" }}>
      <h1>Courses</h1>

      <div style={{ display: "flex", gap: "20px", flexWrap: "wrap" }}>
        {courses.map(course => (
          <CourseCard key={course.id} {...course} />
        ))}
      </div>
    </div>
  );
}

export default Courses;