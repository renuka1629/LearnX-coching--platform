import { useEffect, useState } from "react";
import DashboardLayout from "../layouts/DashboardLayout";

function Dashboard() {
  const [user, setUser] = useState(null);
  const [courses, setCourses] = useState([]);

  useEffect(() => {
    const loggedUser = JSON.parse(localStorage.getItem("user"));

    if (!loggedUser) {
      window.location.href = "/login";
      return;
    }

    setUser(loggedUser);

    const saved = JSON.parse(localStorage.getItem("courses")) || [];
    setCourses(saved);
  }, []);

  return (
    <DashboardLayout user={user}>

      {/* STATS BOXES */}
      <div style={{ display: "flex", gap: "15px", marginBottom: "20px" }}>
        <div className="card" style={{ flex: 1 }}>
          <h3>{courses.length}</h3>
          <p>Enrolled Courses</p>
        </div>

        <div className="card" style={{ flex: 1 }}>
          <h3>{user?.role}</h3>
          <p>User Role</p>
        </div>
      </div>

      {/* COURSES GRID */}
      <h3>My Courses</h3>

      <div style={{
        display: "grid",
        gridTemplateColumns: "repeat(auto-fit, minmax(220px, 1fr))",
        gap: "15px"
      }}>
        {courses.length === 0 ? (
          <div className="card">No courses enrolled yet 🚀</div>
        ) : (
          courses.map((c, i) => (
            <div key={i} className="card">
              <h4>{c.title}</h4>
              <p>{c.instructor}</p>
              <b>₹{c.price}</b>
            </div>
          ))
        )}
      </div>

    </DashboardLayout>
  );
}

export default Dashboard;