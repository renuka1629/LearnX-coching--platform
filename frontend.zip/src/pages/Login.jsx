import { useState } from "react";

function Login() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const handleLogin = () => {
    if (!email || !password) {
      alert("Please fill all fields");
      return;
    }

    // Fake user object (you will later replace with backend)
    const userData = {
      id: Date.now(),
      username: email.split("@")[0],
      email: email,
      role: email.includes("admin") ? "admin" : "user"
    };

    // IMPORTANT: store as JSON string
    localStorage.setItem("user", JSON.stringify(userData));

    // redirect to dashboard
    window.location.href = "/dashboard";
  };

  return (
    <div className="container" style={{
      display: "flex",
      justifyContent: "center",
      alignItems: "center",
      height: "80vh"
    }}>

      <div className="card" style={{ width: "320px" }}>
        <h2 style={{ textAlign: "center" }}>Login</h2>

        <input
          type="email"
          placeholder="Enter email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
        />

        <input
          type="password"
          placeholder="Enter password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
        />

        <button
          className="button"
          style={{ width: "100%", marginTop: "10px" }}
          onClick={handleLogin}
        >
          Login
        </button>
      </div>
    </div>
  );
}

export default Login;