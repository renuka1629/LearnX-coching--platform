function Home() {
  return (
    <div style={{ padding: "40px", textAlign: "center" }}>
      
      <h1 style={{ fontSize: "40px" }}>
        Learn Skills Online 🚀
      </h1>

      <p style={{ fontSize: "18px", color: "gray" }}>
        Join expert-led coaching programs and upgrade your career
      </p>

      <img
        src="https://images.unsplash.com/photo-1522202176988-66273c2fd55f"
        alt="learning"
        style={{ width: "60%", marginTop: "20px", borderRadius: "12px" }}
      />
    </div>
  );
}

export default Home;